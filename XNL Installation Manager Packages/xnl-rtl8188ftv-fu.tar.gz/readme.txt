==========================================================================================================
XNL Package Manager - Install Package - Not intended for manual installs!
==========================================================================================================
Project/Product:		RTL8188FTV/RTL8188FU Driver for the R36S & R36H
By:						XNL Future Technologies & kelebek333 (Github)
Project/Product Page:	https://www.teamxnl.com/R36-RTL8188FTV-DRIVER/
XNL GitHub:				https://github.com/XNLFutureTechnologies/R36-RTL8188FTV-DRIVER
Original Source:		https://github.com/kelebek333/rtl8188fu  
License:				GPL-2.0
  
NOTE:  
DO NOT use this download to install these drivers! This package is intended to be used with the
XNL Package Manager for the R36S and R36H! If you want to download these drivers as standalone
installation then this is possible from the TeamXNL link above. And you can also get the original
installation/drivers from Kelebek333's repository if you want to install it manually. However that
will require you to install quite a few additional packages on your R36 first and also require you
to download and install the kernel headers.
==========================================================================================================
  
==========================================================================================================  
LICENSE NOTE: 
The original license of the original developer of these drivers apply, which is the 
GPL-2.0 License which can be found here:  
https://github.com/kelebek333/rtl8188fu?tab=GPL-2.0-1-ov-file#readme  
==========================================================================================================  
  
  
